package Test;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class framework {

	static WebDriver driver;
	static ExtentReports report;
	static ExtentTest test;


	public static void browser(String browserValue)
	{
		try {
			switch (browserValue) {
			case "Chrome":
				  
				driver = new ChromeDriver();
				test.log(LogStatus.INFO, "Opening Chrome Browser");
				passScreenshot("Chrome");
				break;
			case "Firefox":
				driver = new FirefoxDriver();
				test.log(LogStatus.INFO, "Opening Firefox Browser");
				passScreenshot("Firefox");
				break;
			
			default:
				break;
			}
		} catch (Exception e) {	
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Error in browser method :"+e.getMessage());
			failScreenshot("Browser");
		}
	}


	public static void application(String url)
	{
		try {
			driver.get(url);
			test.log(LogStatus.INFO, "Opening Application URL :"+url);
			passScreenshot("application");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Error in application method :"+e.getMessage());
			failScreenshot("application");
		}
	}


	public static void typeIn(String xpathExpression,String dataValue,String fieldName)
	{
		try {
			driver.findElement(By.xpath(xpathExpression)).sendKeys(dataValue);
			test.log(LogStatus.INFO, "User Enter the value in "+fieldName+" as : "+dataValue);
			passScreenshot(fieldName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Error in typeIn method :"+e.getMessage());
			failScreenshot(fieldName);
		}
	}
	
	public static void clickIn(String xpathExpression,String fieldName)
	{
		try {
			driver.findElement(By.xpath(xpathExpression)).click();
			test.log(LogStatus.INFO, "User Clicked the value in "+fieldName);
			passScreenshot(fieldName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Error in clickIn method :"+e.getMessage());
			failScreenshot(fieldName);
		}
	}

	public static void clearAll(String xpathExpression,String fieldName)
	{
		try {
			driver.findElement(By.xpath(xpathExpression)).clear();
			test.log(LogStatus.INFO, "User clearall the value in "+fieldName);
			passScreenshot(fieldName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Error in clearAll method :"+e.getMessage());
			failScreenshot(fieldName);
		}
	}
	
	
	public static void selectDropDownByValue(String xpathExpression,String valueAttribute,String fieldName)
	{
		try {
			Select dropdown = new Select(driver.findElement(By.xpath(xpathExpression)));
			dropdown.selectByValue(valueAttribute);
			test.log(LogStatus.INFO, "User Selected Dropdown the value in "+fieldName+" as :"+valueAttribute);
			passScreenshot(fieldName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Error in selectDropDownByValue method :"+e.getMessage());
			failScreenshot(fieldName);
		}
	}
	
	public static void selectDropDownByText(String xpathExpression,String textValue,String fieldName)
	{
		try {
			Select dropdown = new Select(driver.findElement(By.xpath(xpathExpression)));
			dropdown.selectByVisibleText(textValue);
			test.log(LogStatus.INFO, "User Selected Dropdown the value in "+fieldName+" as :"+textValue);
			passScreenshot(fieldName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Error in selectDropDownByText method :"+e.getMessage());
			failScreenshot(fieldName);
		}
	}
	
	public static void selectDropDownByOptionNumber(String xpathExpression,int optionNumber,String fieldName)
	{
		try {
			Select dropdown = new Select(driver.findElement(By.xpath(xpathExpression)));
			dropdown.selectByIndex(optionNumber);
			test.log(LogStatus.INFO, "User Selected Dropdown the value in "+fieldName+" as :"+optionNumber);
			passScreenshot(fieldName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Error in selectDropDownByOptionNumber method :"+e.getMessage());
			failScreenshot(fieldName);
		}
	}


	public static String getTitle()
	{
		try {
			return  driver.getTitle();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}


	public static String getUrl()
	{
		try {
			return driver.getCurrentUrl();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}


	public static void windowMax()
	{
		try {
			driver.manage().window().maximize();
			test.log(LogStatus.INFO, "User Maximize the window");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Error in windowMax :"+e.getMessage());
		}
	}

	public static void windowMin()
	{
		try {
			driver.manage().window().minimize();
			test.log(LogStatus.INFO, "User Minimize the window");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Error in windowMin :"+e.getMessage());
		}
	}

	public static void windowFull()
	{
		try {
			driver.manage().window().fullscreen();
			test.log(LogStatus.INFO, "User Fullscreen the window");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Error in windowFull :"+e.getMessage());
		}
	}

	public static void browserBack()
	{
		try {
			driver.navigate().back();
			test.log(LogStatus.INFO, "User Back the Browser");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Error in browserBack :"+e.getMessage());
		}
	}

	public static void browserForward()
	{
		try {
			driver.navigate().forward();
			test.log(LogStatus.INFO, "User Forward the Browser");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Error in browserForward :"+e.getMessage());
		}
	}


	public static void browserRefresh()
	{
		try {
			driver.navigate().refresh();
			test.log(LogStatus.INFO, "User Refresh the Browser");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Error in browserRefresh :"+e.getMessage());
		}
	}
	
	public static void passScreenshot(String imageName) 
	{
	try {
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		File des = new File("./Screenshot/Pass/"+imageName+".png");
		FileUtils.copyFile(src, des);
		test.log(LogStatus.PASS, test.addScreenCapture(des.getAbsolutePath()));
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	}
	public static void failScreenshot(String imageName) 
	{
	try {
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		File des = new File("./Screenshot/Fail/"+imageName+".png");
		FileUtils.copyFile(src, des);
		test.log(LogStatus.FAIL, test.addScreenCapture(des.getAbsolutePath()));
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	}
	
	
	
	public static void report(String fileName)
	{
		try {
			report = new ExtentReports("./Report/"+fileName+".html");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void testcase(String testName,String description)
	{
		try {
			test = report.startTest(testName, description);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void reportSave()
	{
		try {
			report.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void browserClose() 
	{
		try { 
			driver.close(); 
			test.log(LogStatus.INFO, "User Closed the Browser");
			} catch (Exception e) 
		{   e.printStackTrace();
		test.log(LogStatus.ERROR, "Error in browserClose :"+e.getMessage()); 
		}
	}
	
	
	public static void endTestcase()
	{
		try {
			report.endTest(test);;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
