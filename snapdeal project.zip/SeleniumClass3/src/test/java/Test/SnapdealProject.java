package Test;
import org.testng.annotations.Test;
public class SnapdealProject extends framework 
{
	@Test
	public static void Snapdeal() 
	{
		report("SeleniumReport");
	    testcase("Snapdeal Shopping Site", "Verify that user can enter value"); 
	    browser("Chrome");
	    windowMax();
	    application("https://www.snapdeal.com/");
	    typeIn("//input [@id='inputValEnter']"," shoes","Text"); 
	    clickIn("//span[@class='searchTextSpan']","search"); 
	    clickIn("//p [@ title='Bucik Sneakers Black Casual Shoes']","click to view the shoe");
	    endTestcase();
	    reportSave(); 
	}

}
